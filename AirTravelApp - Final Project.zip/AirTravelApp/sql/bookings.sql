-- Schema definition for AirTravelApp bookings table
-- Stores flight booking details submitted via HTML form

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,      -- Unique booking ID (auto-incremented)
    flight_number VARCHAR(10) NOT NULL,     -- Flight number (e.g., CJ715)
    passenger_name VARCHAR(100) NOT NULL,   -- Passenger's full name
    email VARCHAR(100) NOT NULL,            -- Passenger's email address
    confirmation_code VARCHAR(20) NOT NULL, -- Generated confirmation code
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp when booking is created
);

-- Example insert statement for testing
INSERT INTO bookings (flight_number, passenger_name, email, confirmation_code)
VALUES ('CJ715', 'Jay Dobson', 'jay@testemail.com', 'ATX-8392');
