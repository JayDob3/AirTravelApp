package airtravel.service;

import airtravel.model.Booking;
import airtravel.model.Flight;
import airtravel.repository.BookingRepository;
import airtravel.repository.FlightRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.List; // for List.of()


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * BookingServiceTest (Milestone Three)
 * ------------------------------------------------------------
 * Unit tests for BookingService using Mockito to isolate
 * database interactions. These tests verify:
 *
 *  - A booking is created when a valid username and flightId are provided.
 *  - An exception is thrown when the flight does not exist.
 *  - An exception is thrown when the username is empty.
 *
 * These tests do NOT require a Spring context or H2 database.
 * They validate the business logic only.
 */
public class BookingServiceTest {

    private BookingService bookingService;
    private BookingRepository bookingRepository;
    private FlightRepository flightRepository;

    @BeforeEach
    void setUp() {
        bookingRepository = mock(BookingRepository.class);
        flightRepository = mock(FlightRepository.class);

        bookingService = new BookingService(bookingRepository, flightRepository);
    }

    /**
     * Test: Successful booking creation
     * ------------------------------------------------------------
     * Ensures that when a valid username and flightId are provided,
     * BookingService creates a Booking object and saves it using
     * BookingRepository.
     */
    @Test
    void testCreateBookingSuccess() {
        // Arrange
        String username = "Jay";
        long flightId = 1L;

        Flight mockFlight = new Flight();
        mockFlight.setId(flightId);

        when(flightRepository.existsById(flightId)).thenReturn(true);

        when(flightRepository.findById(flightId))
                .thenReturn(Optional.of(mockFlight));

        // IMPORTANT: stub save() so it returns the booking object
        when(bookingRepository.save(any(Booking.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        ArgumentCaptor<Booking> bookingCaptor = ArgumentCaptor.forClass(Booking.class);

        // Act
        Booking result = bookingService.createBooking(username, flightId);

        // Assert
        verify(bookingRepository).save(bookingCaptor.capture());
        Booking savedBooking = bookingCaptor.getValue();

        assertEquals(username, savedBooking.getUsername());
        assertEquals(flightId, savedBooking.getFlightId());
        assertNotNull(savedBooking.getBookingTime());

        // Compare fields, not object identity
        assertEquals(savedBooking.getUsername(), result.getUsername());
        assertEquals(savedBooking.getFlightId(), result.getFlightId());
        assertNotNull(result.getBookingTime());
    }

    /**
     * Test: Flight not found
     * ------------------------------------------------------------
     * Ensures that BookingService throws an exception when the
     * provided flightId does not exist in the database.
     */
    @Test
    void testCreateBookingFlightNotFound() {
        // Arrange
        long flightId = 999L;
        when(flightRepository.findById(flightId))
                .thenReturn(Optional.empty());

        // Act + Assert
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> bookingService.createBooking("Jay", flightId)
        );

        assertTrue(exception.getMessage().contains("does not exist"));
    }

    /**
     * Test: Username is empty
     * ------------------------------------------------------------
     * Ensures that BookingService rejects empty usernames.
     */
    @Test
    void testCreateBookingEmptyUsername() {
        // Arrange
        long flightId = 1L;

        // Act + Assert
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> bookingService.createBooking("", flightId)
        );

        assertEquals("Username must not be empty.", exception.getMessage());
    }
}

