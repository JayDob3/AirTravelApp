package airtravel.service;

import airtravel.model.Flight;
import airtravel.repository.FlightRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * FlightServiceTest (Milestone Three)
 * ------------------------------------------------------------
 * Unit tests for FlightSearchService using Mockito to isolate
 * repository interactions. These tests verify:
 *
 *  - Flights are returned when matching search criteria.
 *  - An empty list is returned when no flights match.
 *  - Search is case-insensitive and flexible.
 *
 * These tests validate business logic only and do not require
 * a Spring context or H2 database.
 */
public class FlightServiceTest {

    private FlightSearchService flightSearchService;
    private FlightRepository flightRepository;

    @BeforeEach
    void setUp() {
        flightRepository = mock(FlightRepository.class);
        flightSearchService = new FlightSearchService(flightRepository);
    }

    /**
     * Test: Matching flights returned
     * ------------------------------------------------------------
     * Ensures that flights matching origin, destination, and date
     * are returned by the search service.
     */
    @Test
    void testSearchFlightsReturnsMatches() {
        // Arrange
        Flight f1 = new Flight("Delta", "BOS", "LAX",
                "2025-01-01T08:00", "2025-01-01T11:00", 350.00);
        Flight f2 = new Flight("United", "BOS", "LAX",
                "2025-01-01T09:00", "2025-01-01T12:00", 375.00);

        List<Flight> mockFlights = new ArrayList<>(List.of(f1, f2));

        when(flightRepository
                .findByOriginContainingIgnoreCaseAndDestinationContainingIgnoreCase(
                        anyString(), anyString()
                )
        ).thenReturn(mockFlights);

        // Act
        List<Flight> results = flightSearchService.searchFlights("bos", "lax", "2025-01-01", 1);

        // Assert
        assertEquals(2, results.size());
        assertEquals("Delta", results.get(0).getAirline());
    }

    /**
     * Test: No matching flights
     * ------------------------------------------------------------
     * Ensures that an empty list is returned when no flights match
     * the search criteria.
     */
    @Test
    void testSearchFlightsReturnsEmptyList() {
        // Arrange
        when(flightRepository
                .findByOriginContainingIgnoreCaseAndDestinationContainingIgnoreCase(
                        anyString(), anyString()
                )
        ).thenReturn(new ArrayList<>());

        // Act
        List<Flight> results = flightSearchService.searchFlights("NYC", "MIA", "2025-01-01", 1);

        // Assert
        assertTrue(results.isEmpty());
    }

    /**
     * Test: Case-insensitive search
     * ------------------------------------------------------------
     * Ensures that search parameters are matched regardless of
     * uppercase/lowercase differences.
     */
    @Test
    void testSearchFlightsCaseInsensitive() {
        // Arrange
        Flight f1 = new Flight("JetBlue", "bos", "mia",
                "2025-01-01T06:00", "2025-01-01T09:00", 220.00);

        when(flightRepository
                .findByOriginContainingIgnoreCaseAndDestinationContainingIgnoreCase(
                        anyString(), anyString()
                )
        ).thenReturn(List.of(f1));

        // Act
        List<Flight> results = flightSearchService.searchFlights("BOS", "MIA", "2025-01-01", 1);

        // Assert
        assertEquals(1, results.size());
        assertEquals("JetBlue", results.get(0).getAirline());
    }
}
