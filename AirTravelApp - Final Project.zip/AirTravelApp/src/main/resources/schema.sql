-- =========================================================
-- Database schema for AirTravelApp (Milestone Three)
-- Creates tables for FLIGHTS and BOOKINGS.
-- =========================================================

CREATE TABLE flights (
    id IDENTITY PRIMARY KEY,
    airline VARCHAR(100) NOT NULL,
    origin VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    departure_time VARCHAR(50) NOT NULL,
    arrival_time VARCHAR(50) NOT NULL,
    price DOUBLE NOT NULL
);

CREATE TABLE bookings (
    id IDENTITY PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    flight_id BIGINT NOT NULL,
    booking_time TIMESTAMP NOT NULL
);
