-- =========================================================
-- Initial flight data for demonstration and testing
-- =========================================================

INSERT INTO flights (airline, origin, destination, departure_time, arrival_time, price)
VALUES
  ('AirTravel', 'Boston', 'New York', '2025-01-10 08:00', '2025-01-10 09:15', 120.00),
  ('AirTravel', 'Boston', 'Chicago', '2025-01-10 11:30', '2025-01-10 13:45', 220.00),
  ('SkyLine', 'New York', 'Los Angeles', '2025-01-11 08:00', '2025-01-11 11:00', 350.00),
  ('AirTravel', 'Chicago', 'Miami', '2025-01-12 14:00', '2025-01-12 18:00', 280.00);
