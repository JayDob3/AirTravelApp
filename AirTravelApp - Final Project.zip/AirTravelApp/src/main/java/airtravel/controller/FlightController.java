package airtravel.controller;

import airtravel.model.Flight;
import airtravel.service.FlightSearchService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * FlightController (Milestone Three Version)
 * ------------------------------------------
 * This controller exposes REST endpoints for retrieving real flight
 * data stored in the H2 database. It delegates all search logic to
 * FlightSearchService, which uses FlightRepository to query the
 * flights table.
 *
 * Endpoints:
 *   GET /api/flights/search?from=...&to=...&date=...&passengers=...
 *   GET /api/flights/ping
 *
 * Notes:
 *  - This replaces the Milestone One version that returned dummy flights.
 *  - Parameter names have been updated to match the frontend (from, to).
 *  - The "date" and "passengers" parameters are validated but not used
 *    for filtering in Milestone Three.
 */
@RestController
@RequestMapping("/api/flights")
@CrossOrigin
public class FlightController {

    private final FlightSearchService flightSearchService;

    /**
     * Constructor-based dependency injection.
     * Spring automatically provides a FlightSearchService bean.
     */
    public FlightController(FlightSearchService flightSearchService) {
        this.flightSearchService = flightSearchService;
        System.out.println(">>> FlightController initialized <<<");
    }

    /**
     * Endpoint: GET /api/flights/search
     * ---------------------------------
     * Accepts query parameters for origin, destination, date, and passenger count.
     * Returns a list of matching flights from the database.
     *
     * IMPORTANT:
     *  - Parameter names MUST match the frontend:
     *        from  → origin city
     *        to    → destination city
     *        date  → travel date (YYYY-MM-DD)
     *        passengers → number of travelers
     *
     * Example:
     *   /api/flights/search?from=Boston&to=Chicago&date=2025-01-10&passengers=1
     *
     * @param from        origin city or airport (mapped from ?from=)
     * @param to          destination city or airport (mapped from ?to=)
     * @param date        travel date (YYYY-MM-DD)
     * @param passengers  number of passengers
     * @return list of matching flights
     */
    @GetMapping("/search")
    public List<Flight> search(@RequestParam String from,
                               @RequestParam String to,
                               @RequestParam String date,
                               @RequestParam int passengers) {

        // Log incoming parameters for debugging
        System.out.println(">>> Search request received: from=" + from +
                ", to=" + to + ", date=" + date + ", passengers=" + passengers);

        // Delegate to service layer
        return flightSearchService.searchFlights(from, to, date, passengers);
    }

    /**
     * Simple health check endpoint.
     *
     * @return confirmation string
     */
    @GetMapping("/ping")
    public String ping() {
        return "FlightController is alive!";
    }
}