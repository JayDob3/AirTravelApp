package airtravel.controller;

import airtravel.model.AuthResponse;
import airtravel.service.AuthClientService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * AuthController (Milestone Three)
 * --------------------------------
 * Handles authentication requests from the frontend.
 *
 * Registration:
 *   - The frontend sends XML directly to the external UserAuthentication API.
 *   - AirTravelApp does NOT handle registration requests.
 *
 * Login:
 *   - The frontend sends FORM DATA (username, password) to AirTravelApp.
 *   - AirTravelApp forwards XML to the external UserAuthentication API.
 *   - The microservice returns XML.
 *   - AirTravelApp converts XML → AuthResponse (JSON).
 *   - JSON is returned to the frontend.
 *
 * This controller completes the required Milestone Three authentication flow.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthClientService authClientService;

    public AuthController(AuthClientService authClientService) {
        this.authClientService = authClientService;
    }

    /**
     * Login Endpoint (Milestone Three)
     * --------------------------------
     * Accepts FORM DATA from the frontend:
     *
     *     username=...
     *     password=...
     *
     * These values are forwarded to AuthClientService, which:
     *   1. Builds XML
     *   2. Sends XML to UserAuthentication
     *   3. Parses XML response
     *   4. Returns AuthResponse (JSON)
     *
     * @param username the username submitted by the user
     * @param password the password submitted by the user
     * @return JSON AuthResponse containing status + message
     */
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(
            @RequestParam("username") String username,
            @RequestParam("password") String password) {

        AuthResponse response = authClientService.login(username, password);
        return ResponseEntity.ok(response);
    }
}
