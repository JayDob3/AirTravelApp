package airtravel.controller;

import airtravel.model.Booking;
import airtravel.service.BookingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * BookingController (Milestone Three Version)
 *
 * This controller handles real flight bookings by forwarding
 * booking requests to BookingService, which stores booking
 * records in the H2 database.
 *
 * Endpoints:
 *  POST /api/bookings/create?username=...&flightId=...
 *
 * Notes:
 *  - This replaces the Milestone One version that generated
 *    mock confirmation codes and did not store bookings.
 *  - This version returns the saved Booking entity.
 */
@RestController
@RequestMapping("/api/bookings")
@CrossOrigin
public class BookingController {

    private final BookingService bookingService;

    /**
     * Constructor-based dependency injection.
     * Spring automatically provides a BookingService bean.
     */
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    /**
     * Creates a new booking for the given username and flight ID.
     *
     * @param username the user making the booking
     * @param flightId the ID of the flight being booked
     * @return the saved Booking entity or an error message
     */
    @PostMapping("/create")
    public ResponseEntity<?> createBooking(@RequestParam String username,
                                           @RequestParam Long flightId) {

        try {
            Booking booking = bookingService.createBooking(username, flightId);
            return ResponseEntity.ok(booking);
        } catch (IllegalArgumentException ex) {
            // Return 400 Bad Request if validation fails
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }
}
