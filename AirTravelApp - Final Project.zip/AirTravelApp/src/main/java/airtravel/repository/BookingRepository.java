package airtravel.repository;

import airtravel.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * BookingRepository provides database access for the Booking entity.
 *
 * This interface allows Spring Data JPA to automatically generate
 * SQL queries for storing and retrieving booking records.
 *
 * Responsibilities:
 *  - Save new bookings created by BookingService
 *  - Retrieve bookings by username (optional for future features)
 *
 * Notes:
 *  - No implementation class is required. Spring generates it at runtime.
 *  - This repository is used by BookingService in Milestone Three.
 */
@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    /**
     * Retrieves all bookings made by the specified username.
     *
     * @param username the user whose bookings should be returned
     * @return list of Booking records for that user
     */
    List<Booking> findByUsername(String username);
}

