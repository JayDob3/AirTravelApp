package airtravel.repository;

import airtravel.model.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * FlightRepository provides database access for the Flight entity.
 *
 * This interface allows Spring Data JPA to automatically generate
 * SQL queries for retrieving flights from the H2 database.
 *
 * Responsibilities:
 *  - Retrieve all flights
 *  - Retrieve flights filtered by origin and destination
 *
 * Notes:
 *  - No implementation class is needed. Spring generates it at runtime.
 *  - This repository is used by FlightSearchService in Milestone Three.
 */
@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {

    /**
     * Finds flights using partial, case-insensitive matching for origin and destination.
     *      *
     *      * @param origin      the departure city/airport (partial match allowed)
     *      * @param destination the arrival city/airport (partial match allowed)
     *      * @return list of matching flights
     */
    List<Flight> findByOriginContainingIgnoreCaseAndDestinationContainingIgnoreCase(
            String origin,
            String destination
    );
}
