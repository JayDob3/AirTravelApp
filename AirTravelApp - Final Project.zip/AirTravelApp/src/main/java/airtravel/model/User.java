package airtravel.model;

/**
 * User represents a customer who can create an account and log in.
 *
 * For this milestone, the class is intentionally simple and is used
 * by AuthService to simulate account creation and authentication.
 */
public class User {

    // Unique username chosen by the user
    private final String username;

    // Plain-text password for simplicity (NOTE: never store passwords
    // in plain text in real applications!)
    private final String password;

    /**
     * Constructs a new User with the given username and password.
     *
     * @param username unique username
     * @param password user password
     */
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * Returns the username.
     *
     * @return username string
     */
    public String getUsername() {
        return username;
    }

    /**
     * Returns the password.
     *
     * @return password string
     */
    public String getPassword() {
        return password;
    }
}

