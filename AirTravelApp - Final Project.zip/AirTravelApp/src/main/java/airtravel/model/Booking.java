package airtravel.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;


/**
 * Booking Entity (Milestone Three)
 * ------------------------------------------------------------
 * Represents a booking stored in the H2 database. Bookings are
 * created through BookingService and returned to the frontend
 * for confirmation.html.
 *
 * Key Milestone Three Notes:
 * - The backend now stores bookings persistently.
 * - Bookings reference a flight by ID, not by flight number.
 * - Username is stored as plain text because authentication is
 *   handled externally.
 */
@Entity
@Table(name = "bookings")
public class Booking {

    /** Primary key for the booking record */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Username of the user who created the booking */
    @Column(nullable = false)
    private String username;

    /** ID of the flight being booked */
    @Column(nullable = false)
    private Long flightId;

    /** Timestamp of when the booking was created */
    @Column(nullable = false)
    private LocalDateTime bookingTime;

    /** Default constructor required by JPA */
    public Booking() {}

    /** Optional convenience constructor */
    public Booking(String username, Long flightId, LocalDateTime bookingTime) {
        this.username = username;
        this.flightId = flightId;
        this.bookingTime = bookingTime;
    }

    // Getters and setters

    public Long getId() { return id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public Long getFlightId() { return flightId; }
    public void setFlightId(Long flightId) { this.flightId = flightId; }

    public LocalDateTime getBookingTime() { return bookingTime; }
    public void setBookingTime(LocalDateTime bookingTime) { this.bookingTime = bookingTime; }
}
