package airtravel.model;

import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlElement;

/**
 * AuthRequest
 * ------------------------------------------------------------
 * This model represents the XML request body sent to the external
 * UserAuthentication microservice during login or registration.
 *
 * The external API expects the following XML structure:
 *
 *   <authRequest>
 *       <username>...</username>
 *       <email>...</email>
 *       <password>...</password>
 *   </authRequest>
 *
 * This class is used exclusively by:
 *   - AuthClientService (Milestone Three)
 *
 * Notes:
 *   - JAXB annotations (@XmlRootElement, @XmlElement) are required
 *     so Spring can serialize this object into XML before sending
 *     it to the external authentication API.
 *   - This class is NOT related to BookingRequest, which belongs
 *     to the flight booking workflow.
 */
@XmlRootElement(name = "authRequest")
public class AuthRequest {

    /** Username submitted for login or registration */
    private String username;

    /** Email submitted for registration (required by XML model) */
    private String email;

    /** Password submitted for login or registration */
    private String password;

    /** Default constructor required for XML serialization */
    public AuthRequest() {}

    /**
     * Convenience constructor for registration
     *
     * @param username the username submitted by the user
     * @param email    the email submitted by the user
     * @param password the password submitted by the user
     */
    public AuthRequest(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    /** @return the username submitted to the authentication API */
    @XmlElement(name = "username")
    public String getUsername() {
        return username;
    }

    /** @param username sets the username for the authentication request */
    public void setUsername(String username) {
        this.username = username;
    }

    /** @return the email submitted to the authentication API */
    @XmlElement(name = "email")
    public String getEmail() {
        return email;
    }

    /** @param email sets the email for the authentication request */
    public void setEmail(String email) {
        this.email = email;
    }

    /** @return the password submitted to the authentication API */
    @XmlElement(name = "password")
    public String getPassword() {
        return password;
    }

    /** @param password sets the password for the authentication request */
    public void setPassword(String password) {
        this.password = password;
    }
}
