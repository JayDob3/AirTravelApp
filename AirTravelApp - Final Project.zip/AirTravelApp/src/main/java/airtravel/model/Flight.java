package airtravel.model;

import jakarta.persistence.*;

/**
 * Flight Entity (Milestone Three)
 * ------------------------------------------------------------
 * Represents a flight stored in the H2 database. This entity is
 * populated by data.sql and queried by FlightRepository.
 *
 * Key Milestone Three Notes:
 * - Field names match the columns defined in schema.sql.
 * - This entity is used by FlightSearchService to return real
 *   flight results to the frontend.
 */
@Entity
@Table(name = "flights")
public class Flight {

    /** Primary key for the flight record */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Airline operating the flight */
    @Column(nullable = false)
    private String airline;

    /** Origin airport code (e.g., BOS) */
    @Column(nullable = false)
    private String origin;

    /** Destination airport code (e.g., LAX) */
    @Column(nullable = false)
    private String destination;

    /** Departure time in ISO-8601 format */
    @Column(nullable = false)
    private String departureTime;

    /** Arrival time in ISO-8601 format */
    @Column(nullable = false)
    private String arrivalTime;

    /** Ticket price for the flight */
    @Column(nullable = false)
    private double price;

    /** Default constructor required by JPA */
    public Flight() {}

    /** Convenience constructor for manual creation */
    public Flight(String airline, String origin, String destination,
                  String departureTime, String arrivalTime, double price) {
        this.airline = airline;
        this.origin = origin;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.price = price;
    }

    // Getters and setters

    public Long getId() { return id; }

    public String getAirline() { return airline; }
    public void setAirline(String airline) { this.airline = airline; }

    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public String getDepartureTime() { return departureTime; }
    public void setDepartureTime(String departureTime) { this.departureTime = departureTime; }

    public String getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(String arrivalTime) { this.arrivalTime = arrivalTime; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public void setId(Long id) { this.id = id; }

}
