package airtravel.model;

import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlElement;


/**
 * AuthResponse
 * ------------------------------------------------------------
 * This model represents the standardized response returned by the
 * external XML-based UserAuthentication API used in Milestone Three.
 *
 * The API returns two key fields:
 *   - status  : indicates success or failure ("SUCCESS", "FAILURE", etc.)
 *   - message : human-readable explanation of the result
 *
 * This class is used by:
 *   - AuthClientService (parses XML responses)
 *   - AuthController (returns JSON to the frontend)
 *
 * Notes:
 *   - JAXB annotations (@XmlRootElement, @XmlElement) are required
 *     so that Spring can deserialize XML responses from the external
 *     authentication microservice.
 *   - This class remains compatible with JSON serialization.
 */
@XmlRootElement(name = "authResponse")
public class AuthResponse {

    /** Status returned by the authentication API (e.g., "SUCCESS", "FAILURE") */
    private String status;

    /** Human-readable message describing the authentication result */
    private String message;

    /**
     * Default constructor required for XML/JSON serialization frameworks.
     */
    public AuthResponse() {}

    /**
     * Convenience constructor for manually creating responses.
     *
     * @param status  the status returned by the authentication API
     * @param message the descriptive message returned by the API
     */
    public AuthResponse(String status, String message) {
        this.status = status;
        this.message = message;
    }

    /** @return the status string returned by the authentication API */
    @XmlElement(name = "status")
    public String getStatus() {
        return status;
    }

    /** @param status sets the status returned by the authentication API */
    public void setStatus(String status) {
        this.status = status;
    }

    /** @return the descriptive message returned by the authentication API */
    @XmlElement(name = "message")
    public String getMessage() {
        return message;
    }

    /** @param message sets the descriptive message returned by the API */
    public void setMessage(String message) {
        this.message = message;
    }
}
