package airtravel.model;

/**
 * BookingRequest represents the data submitted by the user
 * when booking a flight through the HTML form.
 *
 * NOTE (Milestone Three):
 *  - This class is no longer used by the backend booking logic.
 *  - BookingController now accepts `username` and `flightId`
 *    directly as request parameters.
 *  - This DTO is kept only for compatibility with existing
 *    HTML forms from earlier milestones.
 *
 * Fields must match the form input names exactly so Spring
 * can bind them correctly using @ModelAttribute if needed.
 */
public class BookingRequest {

    /** Flight number selected by the user (e.g., "CJ715") */
    private String flightNumber;

    /** Passenger's full name */
    private String passengerName;

    /** Passenger's email address */
    private String email;

    /** Default constructor required for Spring's data binding */
    public BookingRequest() {}

    /** Convenience constructor for manual instantiation */
    public BookingRequest(String flightNumber, String passengerName, String email) {
        this.flightNumber = flightNumber;
        this.passengerName = passengerName;
        this.email = email;
    }

    // Getters and setters

    public String getFlightNumber() {
        return flightNumber;
    }
    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getPassengerName() {
        return passengerName;
    }
    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
}
