package airtravel.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

/**
 * Application-wide configuration class.
 * Defines shared beans such as RestTemplate.
 */
@Configuration
public class AppConfig {

    /**
     * RestTemplate bean used by AuthClientService
     * to communicate with the external authentication API.
     */
    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate();

        // Add JAXB XML converter so RestTemplate can read XML responses
        restTemplate.getMessageConverters().add(new Jaxb2RootElementHttpMessageConverter());

        return restTemplate;
    }
}

