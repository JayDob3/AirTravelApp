package airtravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Entry point for the AirTravelApp application.
 *
 * This Spring Boot application provides:
 *  - Flight search backed by an H2 database
 *  - Flight booking for authenticated users
 *  - Integration with the external XML-based UserAuthentication API
 *
 * It scans all airtravel.* packages for Spring components.
 * This structure supports Milestone Three of the CS-320 project.
 */
@SpringBootApplication
@ComponentScan(basePackages = "airtravel")
public class AirTravelApplication {
    public static void main(String[] args) {
        // Launches the Spring Boot application
        SpringApplication.run(AirTravelApplication.class, args);
    }
}

