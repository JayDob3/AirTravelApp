package airtravel.service;

import airtravel.model.Booking;
import airtravel.repository.BookingRepository;
import airtravel.repository.FlightRepository;
import org.springframework.stereotype.Service;
import java.time.format.DateTimeFormatter;

import java.time.LocalDateTime;

/**
 * BookingService (Milestone Three Version)
 *
 * This service is responsible for creating real booking records
 * in the H2 database. It replaces the Milestone One/Two version
 * that only simulated bookings and checked local login state.
 *
 * Responsibilities:
 *  - Validate that the username is provided
 *  - Validate that the flight exists in the database
 *  - Create and save a booking record
 *  - Return the saved Booking object to the controller
 *
 * Notes:
 *  - This service does NOT check login status. Authentication is
 *    handled entirely by the external XML-based UserAuthentication API.
 *  - This aligns with Milestone Three requirements.
 */
@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final FlightRepository flightRepository;

    /**
     * Constructor-based dependency injection.
     * Spring automatically provides the repository beans.
     */
    public BookingService(BookingRepository bookingRepository,
                          FlightRepository flightRepository) {
        this.bookingRepository = bookingRepository;
        this.flightRepository = flightRepository;
    }

    /**
     * Creates a new booking for the given username and flight ID.
     *
     * @param username the user making the booking
     * @param flightId the ID of the flight being booked
     * @return the saved Booking entity
     *
     * @throws IllegalArgumentException if username is empty or flight does not exist
     */
    public Booking createBooking(String username, Long flightId) {

        // Validate username
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username must not be empty.");
        }

        // Validate flight existence
        if (!flightRepository.existsById(flightId)) {
            throw new IllegalArgumentException("Flight with ID " + flightId + " does not exist.");
        }

        // Create booking record
        Booking booking = new Booking();
        booking.setUsername(username.trim());
        booking.setFlightId(flightId);
        booking.setBookingTime(LocalDateTime.now());

        // Save to database
        return bookingRepository.save(booking);
    }
}
