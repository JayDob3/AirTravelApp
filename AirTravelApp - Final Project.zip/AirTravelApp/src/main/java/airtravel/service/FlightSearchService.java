package airtravel.service;

import airtravel.model.Flight;
import airtravel.repository.FlightRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Comparator;

/**
 * FlightSearchService (Milestone Three Version)
 *
 * This service retrieves flight data from the H2 database using
 * Spring Data JPA. It replaces the dummy flight generation logic
 * used in Milestone One.
 *
 * Responsibilities:
 *  - Validate user input from the frontend
 *  - Query the flights table using FlightRepository
 *  - Return matching flights to the controller
 */
@Service
public class FlightSearchService {

    private final FlightRepository flightRepository;

    /**
     * Constructor-based injection of FlightRepository.
     * Spring automatically provides the repository bean.
     */
    public FlightSearchService(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    /**
     * Searches for flights based on user input.
     *
     * @param from          origin airport/city
     * @param to            destination airport/city
     * @param numPassengers number of travelers
     * @return list of matching flights from the database
     * @throws IllegalArgumentException if inputs are invalid
     */
    public List<Flight> searchFlights(String from, String to, String date, int numPassengers) {

        // --- Validation checks ---
        if (from == null || from.isBlank()) {
            throw new IllegalArgumentException("Origin must not be empty."); }

        if (to == null || to.isBlank()) {
            throw new IllegalArgumentException("Destination must not be empty."); }

        if (numPassengers <= 0) {
            throw new IllegalArgumentException("Number of passengers must be greater than zero."); }

        if (date == null || date.isBlank()) {
            throw new IllegalArgumentException("Date must not be empty."); }

        // --- Query the database using partial, case-insensitive matching (date ignored) ---
        List<Flight> flights = flightRepository .findByOriginContainingIgnoreCaseAndDestinationContainingIgnoreCase(
                from,
                to );

        // --- Sort flights by departure time (earliest first) ---
        flights.sort(Comparator.comparing(Flight::getDepartureTime));

        return flights;
    }
}
