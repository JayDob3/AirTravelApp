package airtravel.service;

import airtravel.model.AuthRequest;
import airtravel.model.AuthResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;

import java.io.StringWriter;
import java.util.List;


/**
 * AuthClientService (Milestone Three)
 * -----------------------------------
 * This service is responsible for forwarding login and registration
 * requests to the external UserAuthentication microservice.
 *
 * It converts AuthRequest objects to XML, sends them via HTTP POST,
 * and parses the XML response into AuthResponse objects.
 *
 * This allows AirTravelApp to delegate all authentication logic
 * to the external service, as required by Milestone Three.
 */
@Service
public class AuthClientService {

    /** Base URL of the external UserAuthentication API */
    @Value("${auth.service.url}")
    private String authServiceUrl;

    /** Shared RestTemplate for sending HTTP requests */
    private final RestTemplate restTemplate;

    public AuthClientService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /**
     * Registers a new user by sending an XML request to the external API.
     *
     * @param username desired username
     * @param email    desired email
     * @param password desired password
     * @return AuthResponse containing status and message
     */
    public AuthResponse register(String username, String email, String password) {
        return sendAuthRequest(username, email, password, "/register");
    }

    /**
     * Attempts to log in by sending credentials to the external API.
     *
     * NOTE:
     * The external XML model requires <email>, even though login does not use it.
     * To satisfy JAXB unmarshalling, we send an empty <email></email> tag.
     *
     * @param username entered username
     * @param password entered password
     * @return AuthResponse containing status and message
     */
    public AuthResponse login(String username, String password) {
        return sendAuthRequest(username, "", password, "/login");
    }

    /**
     * Internal helper method to send XML-based authentication requests.
     *
     * @param username username to send
     * @param email    email to send (empty string allowed for login)
     * @param password password to send
     * @param endpoint either "/login" or "/register"
     * @return parsed AuthResponse from external service
     */
    private AuthResponse sendAuthRequest(String username, String email, String password, String endpoint) {
        try {
            // Build XML payload from AuthRequest
            AuthRequest request = new AuthRequest(username, email, password);
            JAXBContext context = JAXBContext.newInstance(AuthRequest.class);
            Marshaller marshaller = context.createMarshaller();

            StringWriter writer = new StringWriter();
            marshaller.marshal(request, writer);
            String xmlPayload = writer.toString();

            // Prepare HTTP headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_XML);
            headers.setAccept(List.of(MediaType.APPLICATION_XML));

            // Build HTTP entity
            HttpEntity<String> entity = new HttpEntity<>(xmlPayload, headers);

            // Send POST request to external service
            ResponseEntity<AuthResponse> response = restTemplate.exchange(
                    authServiceUrl + endpoint,
                    HttpMethod.POST,
                    entity,
                    AuthResponse.class
            );

            return response.getBody();

        } catch (Exception e) {
            e.printStackTrace();
            return new AuthResponse("FAILURE", "Error communicating with authentication service.");
        }
    }
}
