package airtravel.service;

import airtravel.model.AuthResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * AuthService (Milestone Three Version)
 *
 * This service no longer performs authentication locally.
 * Instead, it forwards all registration and login requests to the
 * external XML-based UserAuthentication microservice created in
 * Milestones One and Two.
 *
 * Responsibilities in Milestone Three:
 *  - Forward registration requests to external API
 *  - Forward login requests to external API
 *  - Return the AuthResponse object received from the external API
 *
 * Notes:
 *  - No users are stored locally.
 *  - No login state is tracked in memory.
 *  - All authentication logic lives in the external microservice.
 */
@Service
public class AuthService {

    /** Base URL of the external UserAuthentication API */
    @Value("${auth.service.url}")
    private String authServiceUrl;

    /** RestTemplate used to send HTTP requests to the external API */
    private final RestTemplate restTemplate = new RestTemplate();

    /**
     * Registers a new user by forwarding the request to the external
     * UserAuthentication service.
     *
     * @param username desired username
     * @param password desired password
     * @return AuthResponse containing status + message
     */
    public AuthResponse registerUser(String username, String password) {
        UserRequest body = new UserRequest(username, password);

        return restTemplate.postForObject(
                authServiceUrl + "/register",
                body,
                AuthResponse.class
        );
    }

    /**
     * Attempts to log in by forwarding credentials to the external
     * UserAuthentication service.
     *
     * @param username username entered by the user
     * @param password password entered by the user
     * @return AuthResponse containing status + message
     */
    public AuthResponse login(String username, String password) {
        UserRequest body = new UserRequest(username, password);

        return restTemplate.postForObject(
                authServiceUrl + "/login",
                body,
                AuthResponse.class
        );
    }

    /**
     * Internal DTO used to send JSON request bodies to the external API.
     */
    static class UserRequest {
        public String username;
        public String password;

        public UserRequest(String username, String password) {
            this.username = username;
            this.password = password;
        }
    }
}
