====================================================
Author: Jay Dobson
Course: IT-634 Distributed Application Development
====================================================
README – AirTravelApp (Milestone Three)
====================================================

Overview
--------
AirTravelApp is a full-stack flight search and booking system built using:

- Java 17
- Spring Boot 3
- H2 in-memory database
- HTML/CSS/JavaScript frontend
- XML-based User Authentication microservice

This project has evolved across three milestones:

- **Milestone One:** Basic flight search, dummy data, simple backend services
- **Milestone Two:** Full UI/UX overhaul, booking flow, consistent styling
- **Milestone Three:** XML-based authentication microservice integration

This README explains how to run the application, how all milestones integrate,
and how to test the full workflow.

------------------------------------------------------------
System Architecture
------------------------------------------------------------

AirTravelApp is one of two coordinated backend services:

1. UserAuthentication Service (Port 8081)
    - Handles login and registration
    - Accepts XML requests
    - Returns XML responses
    - Independent Spring Boot application

2. AirTravelApp Service (Port 8080)
    - Hosts the frontend (HTML/CSS/JS)
    - Provides flight search and booking APIs
    - Stores flights and bookings in H2
    - Communicates with the authentication service before booking

------------------------------------------------------------
Project Structure
------------------------------------------------------------

src/main/java/airtravelapp/
AirTravelApplication.java        -- Spring Boot entry point

controller/                      -- Handles HTTP requests and routing
AuthController.java
BookingController.java
FlightController.java

service/                         -- Business logic layer
AuthService.java
BookingService.java
FlightSearchService.java

repository/                      -- Spring Data JPA repositories
FlightRepository.java
BookingRepository.java

model/                           -- Domain models and DTOs
Flight.java
Booking.java
BookingRequest.java
User.java

config/                          -- (If used) Configuration classes
WebConfig.java (optional)

src/main/resources/
application.properties            -- App configuration (port, H2 settings)
data.sql (if used)                -- Optional initial flight data
static/css/styles.css             -- Shared frontend styling
static/*.html                     -- Frontend pages (index, results, booking, confirmation, login, register)

src/test/java/airtravelapp/
BookingServiceTest.java           -- Unit tests for booking logic
FlightServiceTest.java            -- Unit tests for flight search
AuthServiceTest.java              -- Unit tests for authentication integration
ServiceIntegrationTest.java       -- End‑to‑end service tests

------------------------------------------------------------
How to Run the Application
------------------------------------------------------------

IMPORTANT:
Start the UserAuthentication service BEFORE starting AirTravelApp.

------------------------------------------------------------
Step 1: Start UserAuthentication (Port 8081)
------------------------------------------------------------
1. Navigate to the UserAuthentication project folder.
2. Run:
   mvn spring-boot:run
3. Service starts at:
   http://localhost:8081
4. Endpoints:
   POST /api/auth/login
   POST /api/auth/register

Both endpoints accept and return XML.

------------------------------------------------------------
Step 2: Start AirTravelApp (Port 8080)
------------------------------------------------------------
1. Navigate to the AirTravelApp project folder.
2. Run:
   mvn spring-boot:run
3. Application starts at:
   http://localhost:8080
4. Frontend entry point:
   http://localhost:8080/index.html

------------------------------------------------------------
Authentication Workflow (Milestone Three)
------------------------------------------------------------

AirTravelApp enforces a "login-before-booking" rule.

1. User selects a flight and clicks "Book"
2. If NOT logged in:
   → Redirect to login.html
3. Login form sends XML to UserAuthentication:
   <authRequest>
   <username>Jay</username>
   <password>password123</password>
   </authRequest>
4. UserAuthentication responds with XML:
   <authResponse>
   <status>SUCCESS</status>
   <message>Login successful.</message>
   </authResponse>
5. AirTravelApp stores login state in-memory
6. User is redirected back to booking page for the selected flight
7. Booking is now allowed

------------------------------------------------------------
Backend Components
------------------------------------------------------------

FlightSearchService
- Flexible, case-insensitive search
- Filters by origin, destination, and date
- Repository method:
  findByOriginContainingIgnoreCaseAndDestinationContainingIgnoreCaseAndDepartureTimeContainingIgnoreCase

BookingService
- Validates username and flightId
- Ensures user is authenticated
- Saves booking to H2 database

AuthClientService
- Sends XML login requests to UserAuthentication
- Parses XML responses using JAXB
- Used by LoginController and BookingController

------------------------------------------------------------
Database Schema (H2)
------------------------------------------------------------

Table: flights
- id (PK)
- airline
- origin
- destination
- departure_time
- arrival_time
- price

Table: bookings
- id (PK)
- username
- flight_id
- booking_time

------------------------------------------------------------
Running Unit Tests
------------------------------------------------------------

AirTravelApp includes two major test suites:

1. BookingServiceTest
    - Successful booking creation
    - Flight not found handling
    - Username validation
    - Repository interactions (Mockito)

2. FlightServiceTest
    - Matching flights returned
    - Case-insensitive search
    - Empty results handling

Run all tests:
mvn test

------------------------------------------------------------
Frontend Overview
------------------------------------------------------------

Pages included:

- index.html (search form)
- results.html (dynamic flight results)
- booking-test.html (booking form)
- login.html (XML-based login)
- register.html (XML-based registration)
- confirmation.html (booking confirmation page)
- css/styles.css (shared styling)

Key Milestone Three UI features:
- Accessible blue buttons
- Clean table layout with airline badges
- Back-to-Search button above results table
- Error messages for empty results
- Redirect protection if results.html is accessed directly
- Updated confirmation page with inline primary/secondary actions 
- “Back to Search” (primary button) and “Book Another Flight” (secondary link) placed below booking details

============================================================
Milestone Two Enhancements
============================================================

UI/UX Improvements
------------------
- Consistent styling across all pages
- Accessible form validation
- Card-wrapped results table
- Airline badges for visual clarity
- Inline comments for reviewer clarity

Booking Flow
------------
- Pre-filled booking form
- Confirmation page
- Navigation links (Search Again, Back to Search)

Frontend Structure
------------------
- index.html
- results.html
- booking-test.html
- confirmation.html
- login.html
- register.html

============================================================
Milestone One Enhancements
============================================================

Core Features
-------------
- Basic flight search form
- Dummy flight results
- Simple backend services for:
    - Authentication
    - Flight search
    - Booking

Test Files
----------
- AuthServiceTest
- FlightSearchServiceTest
- BookingServiceTest
- ServiceIntegrationTest

Console Demo
------------
Running Main.java demonstrates:
- Login
- Flight search
- Booking

------------------------------------------------------------
Known Limitations
------------------------------------------------------------

- Login state stored in-memory (no sessions/JWT)
- H2 database resets on restart
- XML parsing is minimal by design

============================================================
End of README
============================================================