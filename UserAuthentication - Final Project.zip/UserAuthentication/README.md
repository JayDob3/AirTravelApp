====================================================
Author: Jay Dobson
Course: IT-634 Distributed Application Development
====================================================
README – UserAuthentication Service (Milestone Three)
====================================================

Overview
--------
The UserAuthentication service is a standalone Spring Boot 3
microservice responsible for handling user login and registration.
It communicates exclusively using XML for both requests and
responses, and persists user accounts in a local XML file using
JAXB.

This service is consumed by the AirTravelApp (Milestone Three),
which requires successful authentication before allowing users
to book flights.

------------------------------------------------------------
Key Features
------------------------------------------------------------
- XML-based login and registration
- JAXB persistence to users.xml
- Fully annotated User and Users models
- Independent Spring Boot application (port 8081)
- Validates credentials for AirTravelApp
- Returns structured XML responses:
  <authResponse>
  <status>SUCCESS|FAILURE</status>
  <message>...</message>
  </authResponse>

------------------------------------------------------------
Endpoints
------------------------------------------------------------

POST /api/auth/login
- Accepts XML:
  <authRequest>
  <username>...</username>
  <password>...</password>
  </authRequest>

- Returns XML:
  <authResponse>
  <status>SUCCESS|FAILURE</status>
  <message>...</message>
  </authResponse>

POST /api/auth/register
- Accepts XML:
  <user>
  <username>...</username>
  <email>...</email>
  <password>...</password>
  </user>

- Returns XML response identical to login

------------------------------------------------------------
How to Run the Service
------------------------------------------------------------

1. Navigate to the UserAuthentication project folder.
2. Start the service:
   mvn spring-boot:run
3. The service runs on:
   http://localhost:8081
4. AirTravelApp must be configured with:
   auth.service.url=http://localhost:8081/api/auth

------------------------------------------------------------
XML Persistence
------------------------------------------------------------

User accounts are stored in:
src/main/resources/users.xml

The file is automatically created on first registration if it does not already exist.
All new users are appended to this XML file, and the data persists across application restarts.

JAXB-annotated models:
- User.java
- Users.java (wrapper list)
- SimpleResponse.java (XML response wrapper)

------------------------------------------------------------
Project Structure
------------------------------------------------------------

src/main/java/com/example/auth/
controller/
AuthController.java          -- Handles /login and /register XML endpoints
model/
User.java                    -- JAXB-annotated user model
Users.java                   -- Wrapper list for XML persistence
SimpleResponse.java          -- Standard XML response wrapper
service/
UserService.java             -- Core logic for authentication and registration
util/
XmlUtil.java                 -- Helper for reading/writing users.xml (if applicable)

src/main/resources/
users.xml                        -- Auto-created XML user store
application.properties           -- Service configuration (port, context path)

src/test/java/com/example/auth/
AuthControllerTest.java          -- XML request/response tests (if included)
UserServiceTest.java             -- Unit tests for authentication logic

------------------------------------------------------------
Integration with AirTravelApp
------------------------------------------------------------

AirTravelApp sends XML login requests using RestTemplate.
This service validates credentials and returns an XML response.

Example login flow:

Request:
<authRequest>
<username>Jay</username>
<password>password123</password>
</authRequest>

Response:
<authResponse>
<status>SUCCESS</status>
<message>User authenticated successfully.</message>
</authResponse>

If authentication fails, AirTravelApp displays an error and
prevents booking.

------------------------------------------------------------
Technologies Used
------------------------------------------------------------
- Java 17
- Spring Boot 3
- JAXB (XML marshalling/unmarshalling)
- Local XML persistence (users.xml)
- RESTful API design

------------------------------------------------------------
Known Limitations
------------------------------------------------------------
- No password hashing (plain text for milestone simplicity)
- No duplicate username validation beyond simple checks
- No session or token-based authentication
- XML file grows indefinitely unless manually cleared

============================================================
End of README
============================================================
