package com.example.userauthentication.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;

/**
 * XmlConfig
 * ---------
 * Spring Boot 3 no longer registers JAXB XML converters automatically.
 *
 * Spring will NOT deserialize XML request bodies into Java objects unless
 * a Jaxb2RootElementHttpMessageConverter bean is explicitly registered.
 *
 *By defining this bean, I tell Spring:
 *   "Yes, this application supports JAXB XML marshalling/unmarshalling."
 *
 * After adding this config:
 *   - Spring will correctly deserialize <authRequest> into User.java
 *   - The controller will receive a populated User object
 *   - Registration will succeed and return <simpleResponse> XML
 */
@Configuration
public class XmlConfig {

    /**
     * Registers the JAXB XML message converter.
     *
     * Spring Boot automatically picks up this bean and adds it to the list
     * of HttpMessageConverters used for @RequestBody and @ResponseBody.
     *
     * This enables:
     *   - XML → Java (unmarshalling)
     *   - Java → XML (marshalling)
     *
     * Required for:
     *   - POST /api/auth/register
     *   - POST /api/auth/login
     */
    @Bean
    public Jaxb2RootElementHttpMessageConverter jaxb2RootElementHttpMessageConverter() {
        return new Jaxb2RootElementHttpMessageConverter();
    }
}

