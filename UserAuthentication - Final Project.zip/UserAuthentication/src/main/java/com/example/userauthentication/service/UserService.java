package com.example.userauthentication.service;

import com.example.userauthentication.model.User;
import com.example.userauthentication.model.Users;
import jakarta.annotation.PostConstruct;
import jakarta.xml.bind.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Optional;

/**
 * UserService (XML Persistence Layer)
 * -----------------------------------
 * This service manages:
 *   - Loading users from users.xml
 *   - Saving updated user lists back to XML
 *   - Authenticating users
 *   - Registering new users
 *
 * Milestone Three Notes:
 *   - This service is called by AuthController when AirTravelApp
 *     sends XML <authRequest> payloads for login and registration.
 *   - The User model now includes: username, email, password.
 *   - All XML operations use JAXB for marshalling/unmarshalling.
 */
@Service
public class UserService {

    /** Path to the XML file storing user data (configured in application.properties) */
    @Value("${users.file.path}")
    private String usersFilePath;

    /** File object pointing to the XML file */
    private File usersFile;

    /** JAXB context used for XML marshalling/unmarshalling */
    private JAXBContext jaxbContext;

    /**
     * Initializes JAXB and ensures the XML file exists.
     * Runs automatically after Spring constructs this service.
     */
    @PostConstruct
    public void init() {
        try {
            // Create JAXB context for the Users wrapper class
            jaxbContext = JAXBContext.newInstance(Users.class);

            // Create File object for the XML file path
            usersFile = new File(usersFilePath);

            // If the XML file does not exist, create an empty <users> root element
            if (!usersFile.exists()) {
                Users empty = new Users();
                saveUsers(empty);
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize UserService", e);
        }
    }

    /**
     * Loads all users from the XML file.
     * Synchronized to prevent concurrent read/write issues.
     *
     * @return Users object containing all stored user accounts
     */
    private synchronized Users loadUsers() {
        try {
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            return (Users) unmarshaller.unmarshal(usersFile);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load users from XML", e);
        }
    }

    /**
     * Saves the given Users object back to the XML file.
     * Synchronized to ensure safe write operations.
     *
     * @param users the Users object to persist
     */
    private synchronized void saveUsers(Users users) {
        try {
            Marshaller marshaller = jaxbContext.createMarshaller();

            // Format XML output for readability
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            marshaller.marshal(users, usersFile);
        } catch (Exception e) {
            throw new RuntimeException("Failed to save users to XML", e);
        }
    }

    /**
     * Authenticates a user by checking if a matching username/password
     * pair exists inside the XML file.
     *
     * @param username the username entered by the user
     * @param password the password entered by the user
     * @return true if credentials match an existing user, false otherwise
     */
    public boolean authenticate(String username, String password) {

        // Basic validation: reject empty or null values
        if (username == null || username.trim().isEmpty() ||
                password == null || password.trim().isEmpty()) {
            return false;
        }

        Users users = loadUsers();

        // Search for a matching username/password pair
        Optional<User> match = users.getUsers().stream()
                .filter(u -> u.getUsername().equals(username)
                        && u.getPassword().equals(password))
                .findFirst();

        return match.isPresent();
    }

    /**
     * Registers a new user by:
     *  - Validating that username, email, and password are not empty
     *  - Checking if the username already exists
     *  - Adding the new user to the XML file if valid
     *
     * @param username the desired username
     * @param email the desired email address
     * @param password the desired password
     * @return true if registration succeeded, false otherwise
     */
    public boolean register(String username, String email, String password) {

        // Server-side validation: prevent empty fields
        if (username == null || username.trim().isEmpty() ||
                email == null || email.trim().isEmpty() ||
                password == null || password.trim().isEmpty()) {
            return false;
        }

        Users users = loadUsers();

        // Check for duplicate username
        boolean exists = users.getUsers().stream()
                .anyMatch(u -> u.getUsername().equals(username));

        if (exists) {
            return false; // Username already taken
        }

        // Add new user and save updated list
        users.getUsers().add(new User(username, email, password));
        saveUsers(users);

        return true;
    }
}
