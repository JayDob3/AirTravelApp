package com.example.userauthentication.controller;

import com.example.userauthentication.model.AuthRequest;
import com.example.userauthentication.model.AuthResponse;
import org.springframework.web.bind.annotation.*;

/**
 * UserAuthentication AuthController
 * ---------------------------------
 * This controller receives XML login and registration requests
 * from the AirTravelApp (Milestone Three).
 *
 * Endpoints:
 *   POST /api/auth/register   (XML)
 *   POST /api/auth/login      (XML)
 *
 * Both endpoints accept and return XML.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    /**
     * Login Endpoint (XML)
     * --------------------
     * Accepts:
     * <authRequest>
     * <username>...</username>
     * <email></email>   <-- may be empty for login
     * <password>...</password>
     * </authRequest>
     * <p>
     * Returns:
     * <authResponse>
     * <status>SUCCESS|FAILURE</status>
     * <message>...</message>
     * </authResponse>
     */
    @PostMapping(value = "/login", consumes = "application/xml", produces = "application/xml")
    public AuthResponse login(@RequestBody AuthRequest request) {

        System.out.println("Received login request for user: " + request.getUsername());

        // Dummy authentication logic for milestone
        if ("Jay".equals(request.getUsername()) && "test123".equals(request.getPassword())) {
            return new AuthResponse("SUCCESS", "User authenticated successfully.");
        }

        System.out.println("Returning FAILURE response");
        return new AuthResponse("FAILURE", "Invalid username or password.");
    }
}
