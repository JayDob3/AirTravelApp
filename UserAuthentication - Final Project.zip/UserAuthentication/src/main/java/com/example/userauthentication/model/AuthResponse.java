package com.example.userauthentication.model;

import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlElement;

/**
 * AuthResponse (UserAuthentication Microservice)
 * ----------------------------------------------
 * Represents the outgoing XML response for login or registration.
 *
 * Returned XML structure:
 *   <authResponse>
 *       <status>SUCCESS|FAILURE</status>
 *       <message>...</message>
 *   </authResponse>
 *
 * This model is used by the microservice to send authentication results
 * back to the AirTravelApp.
 */
@XmlRootElement(name = "authResponse")
public class AuthResponse {

    private String status;
    private String message;

    /** Default constructor required for JAXB */
    public AuthResponse() {}

    /**
     * Constructs an AuthResponse with status and message.
     *
     * @param status  SUCCESS or FAILURE
     * @param message explanation or error detail
     */
    public AuthResponse(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @XmlElement
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @XmlElement
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
