package com.example.userauthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the User Authentication web service.
 *
 * This Spring Boot application exposes REST endpoints for:
 *  - Registering new users
 *  - Authenticating existing users
 *
 * User data is stored in a local XML file using JAXB.
 */
@SpringBootApplication
public class UserAuthenticationApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserAuthenticationApplication.class, args);
    }
}
