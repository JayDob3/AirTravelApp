package com.example.userauthentication.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

/**
 * Configures Spring MVC to support JAXB-based XML serialization.
 * Required in Spring Boot 3 to enable XML responses from controllers.
 */
@Configuration
public class JaxbConfig implements WebMvcConfigurer {

    @Override public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
        converters.add(new Jaxb2RootElementHttpMessageConverter());
    }
}

