package com.example.userauthentication.model;

import jakarta.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Wrapper class representing the root <users> element in the XML file.
 *
 * JAXB requires a single root element when marshalling/unmarshalling
 * collections, so this class holds a List<User>.
 */
@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class Users {

    /** List of <user> elements inside the XML file */
    @XmlElement(name = "user")
    private List<User> users = new ArrayList<>();

    /** Default constructor required by JAXB */
    public Users() {}

    // Getters and setters
    public List<User> getUsers() { return users; }
    public void setUsers(List<User> users) { this.users = users; }
}
