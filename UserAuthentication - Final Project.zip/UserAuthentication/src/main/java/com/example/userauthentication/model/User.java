package com.example.userauthentication.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * User (XML Model)
 * ----------------
 * Represents a single user record and also the request body for
 * login/register when AirTravelApp sends XML payloads.
 *
 * Expected XML format:
 *
 *   <authRequest>
 *       <username>Jay</username>
 *       <email>jay@testemail.com</email>
 *       <password>test123</password>
 *   </authRequest>
 */
@XmlRootElement(name = "authRequest")   // Root element expected by AirTravelApp
@XmlAccessorType(XmlAccessType.FIELD)   // JAXB reads/writes fields directly
public class User {

    /**
     * Username field
     * Appears inside <username> in XML.
     */
    @XmlElement
    private String username;

    /**
     * email field
     * Appears inside <email> in XML.
     */
    @XmlElement
    private String email;

    /**
     * Password field
     * Appears inside <password> in XML.
     */
    @XmlElement
    private String password;

    /**
     * Default no-argument constructor
     * REQUIRED by JAXB for XML marshalling/unmarshalling.
     */
    public User() {}

    /**
     * Constructor for creating new users in code.
     */
    public User(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() { return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
