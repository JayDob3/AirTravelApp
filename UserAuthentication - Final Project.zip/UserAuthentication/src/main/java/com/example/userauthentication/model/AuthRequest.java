package com.example.userauthentication.model;

import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlElement;

/**
 * AuthRequest (UserAuthentication Microservice)
 * ---------------------------------------------
 * Represents the incoming XML payload for login or registration.
 *
 * Expected XML structure:
 *   <authRequest>
 *       <username>...</username>
 *       <email>...</email>
 *       <password>...</password>
 *   </authRequest>
 *
 * This model is used by the microservice to receive authentication requests
 * from the AirTravelApp. The <email> field may be empty for login.
 */
@XmlRootElement(name = "authRequest")
public class AuthRequest {

    private String username;
    private String email;
    private String password;

    /** Default constructor required for JAXB */
    public AuthRequest() {}

    /**
     * Constructs an AuthRequest with all fields.
     *
     * @param username the username
     * @param email    the email (may be empty for login)
     * @param password the password
     */
    public AuthRequest(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    @XmlElement
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @XmlElement
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @XmlElement
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
