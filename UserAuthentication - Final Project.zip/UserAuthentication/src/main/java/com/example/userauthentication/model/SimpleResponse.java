package com.example.userauthentication.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * XML wrapper for authentication responses.
 *
 * Produces:
 * <authResponse>
 *     <status>SUCCESS</status>
 *     <message>User registered successfully.</message>
 * </authResponse>
 */
@XmlRootElement(name = "authResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class SimpleResponse {

    @XmlElement
    private String status;

    @XmlElement
    private String message;

    public SimpleResponse() {}

    public SimpleResponse(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public String getStatus() { return status; }
    public String getMessage() { return message; }

    public void setStatus(String status) { this.status = status; }
    public void setMessage(String message) { this.message = message; }
}

